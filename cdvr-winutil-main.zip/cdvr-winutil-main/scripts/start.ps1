<#
.NOTES
    CDVR WinUtil - a Channels DVR-focused fork of WinUtil.
    Fork    : https://github.com/bnhf/cdvr-winutil

    Original WinUtil:
    Author         : Chris Titus @christitustech
    Runspace Author: @DeveloperDurp
    GitHub         : https://github.com/ChrisTitusTech
    Version        : #{replaceme}
#>

param (
    [string]$Config,
    [ValidateSet("Standard", "Minimal", "Advanced", "")]
    [string]$Preset,
    [switch]$Offline
)

$PARAM_OFFLINE = $false
if ($Offline) {
    $PARAM_OFFLINE = $true
}

if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    Write-Host "WinUtil is unable to run on your system. PowerShell execution is restricted by security policies." -ForegroundColor Red
    return
}

if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Output "WinUtil needs to be run as Administrator. Attempting to relaunch."
    $argList = @()

    $PSBoundParameters.GetEnumerator() | ForEach-Object {
        $argList += if ($_.Value -is [switch] -and $_.Value) {
            "-$($_.Key)"
        } elseif ($_.Value -is [array]) {
            "-$($_.Key) $($_.Value -join ',')"
        } elseif ($_.Value) {
            "-$($_.Key) '$($_.Value)'"
        }
    }

    $script = if ($PSCommandPath) {
        "& { & `'$($PSCommandPath)`' $($argList -join ' ') }"
    } else {
        # Download to a local temp file and elevate via that file, rather than fetching and
        # executing the remote script inline within the elevated command - "download and
        # immediately execute" is a well-known trigger for antivirus/Defender false positives.
        # This also lets $PSCommandPath resolve normally in the elevated instance - matching
        # the winutil-*.ps1 pattern Remove-WinUtilTempScript already expects and cleans up.
        $tempScriptPath = Join-Path ([IO.Path]::GetTempPath()) "winutil-$([guid]::NewGuid().ToString('N')).ps1"
        Invoke-WebRequest -Uri "https://raw.githubusercontent.com/bnhf/cdvr-winutil/main/winutil.ps1" -OutFile $tempScriptPath -UseBasicParsing
        "& { & `'$tempScriptPath`' $($argList -join ' ') }"
    }

    # Elevate powershell/pwsh directly rather than wrapping in wt.exe - Windows Terminal's
    # wt.exe is often an MSIX app-execution-alias stub, and UAC elevation via ShellExecute's
    # "runas" verb frequently fails to cross that redirection (error 0x80070005/0x80070002,
    # "error ... when launching '...'" - a known recurring class of issue upstream).
    $powershellCmd = if (Get-Command pwsh -ErrorAction SilentlyContinue) { "pwsh" } else { "powershell" }
    Start-Process $powershellCmd -ArgumentList "-ExecutionPolicy Bypass -NoProfile -Command `"$script`"" -Verb RunAs

    break
}

# Variable to sync between runspaces
$sync = [Hashtable]::Synchronized(@{})
$sync.version = "#{replaceme}"
$sync.configs = @{}
$sync.Buttons = [System.Collections.Generic.List[PSObject]]::new()
$sync.preferences = @{}
$sync.ProcessRunning = $false
$sync.Win11ISOProcessRunning = $false
$sync.selectedAppx = [System.Collections.Generic.List[string]]::new()
$sync.selectedApps = [System.Collections.Generic.List[string]]::new()
$sync.selectedTweaks = [System.Collections.Generic.List[string]]::new()
$sync.selectedToggles = [System.Collections.Generic.List[string]]::new()
$sync.selectedFeatures = [System.Collections.Generic.List[string]]::new()
$sync.currentTab = "Install"

$dateTime = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$winutildir = "$env:LocalAppData\winutil"
$sync.winutildir = $winutildir

$logdir = "$winutildir\logs"
$sync.logPath = "$logdir\winutil_$dateTime.log"
$sync.transcriptPath = $sync.logPath
Start-Transcript -Path $sync.logPath -Append -NoClobber | Out-Null

$Host.UI.RawUI.WindowTitle = "CDVR WinUtil"
Clear-Host
